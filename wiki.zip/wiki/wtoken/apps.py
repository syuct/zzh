from django.apps import AppConfig


class WtokenConfig(AppConfig):
    name = 'wtoken'
